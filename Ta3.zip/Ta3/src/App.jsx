import React from "react"
import Input from "./components/Card/input";


function App() {
    return (
        <div>
            <h1>Escribe algo</h1>
            <Input />
        </div>
    );
}

export default App;
