import React, { useState } from "react";

const Input = () => {
    const [inputValue, setInputValue] = useState(""); // Estado para almacenar el valor ingresado

    const handleInputChange = (event) => {
        setInputValue(event.target.value); // Actualiza el valor cada vez que cambia el input
    };

    return (
        <div>
            <input 
                type="text" 
                value={inputValue} 
                onChange={handleInputChange} 
                placeholder="Escribe algo aquí..." 
            />
            <p>Lo que estas escribiendo: {inputValue}</p> 
        </div>
    );
};

export default Input;
