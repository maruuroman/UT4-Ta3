import React from "react";
import classes from "./index.module.css"; 

const Etiqueta = ({ children }) => {
    return (
        <div className={classes.etiqueta}>
            {children}{}
        </div>
    );
};

export default Etiqueta